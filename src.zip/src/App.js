import logo from "./logo.svg";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import ImageUpload from "./components/ImageUploader";
import NavbarComp from "./Navigation/NavbarComp.js";

function App() {
  return (
    <div>
      <NavbarComp />
      <div className="center text">
      <ImageUpload />
      </div>
      
    </div>
  );
}

export default App;
