// pages/Home.js
import React from "react";


function Home() {
  return (
    <div className="center text">
      In this application you can detect a plant health by uploading image here.
      <div className="container">
      
      </div>
    </div>
  );
}

export default Home;
